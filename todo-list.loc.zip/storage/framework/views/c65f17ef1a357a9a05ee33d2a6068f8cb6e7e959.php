<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

	        <form action="<?php echo e(route('add-task')); ?>" method="POST">
	        	<?php echo csrf_field(); ?>
	        	<input type="hidden" name="parent_id" value="1">
	        	
	        	<input type="text" name="task">
				
				<button>send</button>
	        </form>

        </div>
		
		<div class="col-md-8">
			<table-todo></table-todo>
		</div>
    </div>
</div>

<?php if(!empty($qr)): ?>
	
	<pre><?php echo e(print_r($qr, true)); ?></pre>

<?php endif; ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\OSPanel\domains\todo-list.loc\resources\views/panel/dashboard.blade.php */ ?>